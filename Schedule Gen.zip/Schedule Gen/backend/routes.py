from flask import Blueprint,jsonify,request
import os 
import shutil
import tempfile
from werkzeug.utils import secure_filename
bp=Blueprint('routes',__name__)
from core.document_processor import process_doc



# Upload endpoint
@bp.route('/upload',methods=['POST'])
def upload_files():
    if "file" not in request.files:
        return jsonify({"Error":"No file found"}),400
    
    file=request.files["file"]
    
    if file.filename=="" or not file.filename.lower().endswith(('.pdf', '.docx')): #type: ignore 
        return jsonify({"Error":"Invalid file"}),400
    
    temp_dir=tempfile.mkdtemp() #Creating temp directory 
    
    try:
        fname=secure_filename(filename=file.filename) #type: ignore
        f_path=os.path.join(temp_dir,fname) 
        file.save(f_path)
    
        res=process_doc(f_path,os.path.splitext(f_path)[1].strip("."))
        if res:
            return jsonify({"Message":"Succesfully Processed the document"})
        else:
            return jsonify({"Error": "Document processing failed"}), 500
    except Exception as e:
        return jsonify({"Error":str(e)}),500 
    
    finally:
        shutil.rmtree(temp_dir,ignore_errors=True)
        
        
