from langchain_community.document_loaders import PyPDFLoader,Docx2txtLoader 
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain.schema import Document
from langchain_pinecone import PineconeVectorStore
import os 
from dotenv import load_dotenv
import re 

load_dotenv()



def process_doc(file_path,doc_type):
    
    # Minimal Preprocessing
    def clean_text(text): 
        text=re.sub(r"\s+"," ",text)
        text = text.replace("“", '"').replace("”", '"')
        text = text.replace("‘", "'").replace("’", "'")
        text = text.replace("–", "-").replace("—", "-")
        return text.strip()
    
    
    pages=[]
    if doc_type=="pdf":
        loader=PyPDFLoader(file_path=file_path)
        for page in loader.lazy_load(): 
            doc=clean_text(page.page_content)
            pages.append(Document(page_content=doc,metadata=page.metadata))
    elif doc_type=="docx":
        loader=Docx2txtLoader(file_path=file_path)
        for page in loader.load():
            doc = clean_text(page.page_content)
            pages.append(Document(page_content=doc, metadata=page.metadata))
        
    
    # Chunking 
    
    splitter=RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=100
    )
    chunks=splitter.split_documents(pages)
    
    for idx, chunk in enumerate(chunks):
        chunk.metadata["source_file"] = os.path.basename(file_path)
        chunk.metadata["page_number"] = idx + 1  
    
    # Generating embeddings
    
    model=GoogleGenerativeAIEmbeddings(google_api_key=os.getenv("GOOGLE_API_KEY"),model="gemini-embedding-001") #type: ignore
    
    # Using pinecone to store the embeddings
    
    vstore=PineconeVectorStore(index_name=os.getenv('INDEX_NAME'),embedding=model)
    vstore.add_documents(chunks)
    
    print("Succesful")
    
    
    
process_doc(r"C:\Personal\Coding\Projects\Schedule Gen\rag and agentic ai.pdf","pdf")