import json 
import os 
import logging

logger=logging.getLogger(__name__)


def extract_json(raw_text):
    if not raw_text:
        return None
    
    txt=raw_text.strip()
    start,end=txt.find('{'),txt.rfind('}')
    
    if start==-1 or end==-1 or start>=end:
        try:
            return json.loads(txt)
        except Exception:
            return None
    candidate=txt[start:end+1]
    try:
        return json.loads(candidate)
    except Exception:
        try:
            return json.loads(txt)
        except Exception:
            return None 
        
        
        
def assemble_context(prompt,matches,prefs):
    parts=["USER_PROMPT_START",prompt,"USER_PROMPT_END"]
    
    # Adding the retrieved chunks 
    parts.append("RETRIEVED_CONTENT_START")
    
    for i,m in enumerate(matches,start=1):
        md=m.get('metadata',{}) or {}
        excerpt=(md.get('text') or "")[:800]
        src = md.get("document_source") or md.get("file_id") or md.get("chunk_id") or ""
        parts.append(f"CHUNK_{i} id={m.get('id')} score={m.get('score')}\nSOURCE={src}\nEXCERPT={excerpt}\n")
    parts.append("RETRIEVED_CONTENT_END")
    parts.append(f"USER_PREFERENCES={json.dumps(prefs)}")
    return "\n".join(parts)


